<?php

namespace Planogolny\GIS\Services;

use Planogolny\GIS\DTO\CoordinatesDTO;
class OsmProvider
{
    public function fetchBuildings(CoordinatesDTO $coords): array
    {
        return [];
    }

    public function fetchRoads(CoordinatesDTO $coords): array
    {
        return [];
    }

    public function fetchRail(CoordinatesDTO $coords): array
    {
        return [];
    }

    public function fetchWater(CoordinatesDTO $coords): array
    {
        return [];
    }
}
