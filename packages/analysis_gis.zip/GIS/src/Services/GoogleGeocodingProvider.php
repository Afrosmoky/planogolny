<?php

namespace Planogolny\GIS\Services;

use Planogolny\GIS\DTO\CoordinatesDTO;
class GoogleGeocodingProvider
{
    public function geocode(string $address): ?CoordinatesDTO
    {
        // TODO: implement after API setup
        return null;
    }
}
