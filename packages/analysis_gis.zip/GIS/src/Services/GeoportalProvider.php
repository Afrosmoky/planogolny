<?php

namespace Planogolny\GIS\Services;

use Planogolny\GIS\DTO\CoordinatesDTO;
use Planogolny\GIS\DTO\ParcelDTO;
class GeoportalProvider
{
    public function identifyParcel(CoordinatesDTO $coords): ParcelDTO
    {
        return new ParcelDTO(
            gmina: null,
            powiat: null,
            wojewodztwo: null,
            parcelId: null,
            raw: []
        );
    }
}
