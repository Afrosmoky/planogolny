<?php

namespace Planogolny\GIS\Exceptions;

use Exception;
class GisException extends Exception
{

}
