<?php

namespace Planogolny\GIS\DTO;

final readonly class ParcelDTO
{
    public function __construct(
        public ?string $gmina,
        public ?string $powiat,
        public ?string $wojewodztwo,
        public ?string $parcelId = null,
        public array $raw = [] // RAW response for debugging
    ) {}
}
