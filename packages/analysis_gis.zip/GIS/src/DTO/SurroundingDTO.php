<?php

namespace Planogolny\GIS\DTO;

final readonly class SurroundingDTO
{
    public function __construct(
        public array $buildings = [],
        public array $roads = [],
        public array $rail = [],
        public array $water = []
    ) {}
}
