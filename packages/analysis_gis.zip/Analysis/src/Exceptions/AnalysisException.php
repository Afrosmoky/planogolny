<?php

namespace Planogolny\Analysis\Exceptions;

use Exception;
class AnalysisException extends Exception
{

}
