<?php

namespace Planogolny\Analysis\Services;

use Planogolny\Analysis\DTO\AnalysisInputDTO;
use Planogolny\Analysis\DTO\ConstraintsDTO;

final class RestrictionService
{
    /**
     * @return array{
     *   penalties: array<string,int>,
     *   warnings: string[]
     * }
     */
    public function apply(AnalysisInputDTO $input): array
    {
        $penalties = [];
        $warnings = [];

        $constraints = $input->constraints;

        // 🌊 Rzeka
        if ($constraints->river->exists) {
            $distance = $constraints->river->distanceMeters;

            if ($distance !== null && $distance < 50) {
                $penalties['single_family'] = 10;
                $penalties['multi_family'] = 15;
                $warnings[] = "Działka znajduje się {$distance} m od rzeki";
            }
        }

        // 🚆 Kolej
        if ($constraints->railway->exists) {
            $distance = $constraints->railway->distanceMeters;

            if ($distance !== null && $distance < 20) {
                $penalties['single_family'] = ($penalties['single_family'] ?? 0) + 10;
                $penalties['services'] = ($penalties['services'] ?? 0) + 5;
                $warnings[] = "Bliskość linii kolejowej ({$distance} m)";
            }
        }

        // 🛣 Droga szybkiego ruchu / autostrada
        if ($constraints->highway->exists) {
            $distance = $constraints->highway->distanceMeters;

            if ($distance !== null && $distance < 30) {
                $penalties['single_family'] = ($penalties['single_family'] ?? 0) + 15;
                $penalties['green'] = ($penalties['green'] ?? 0) + 5;
                $warnings[] = "Bliskość drogi szybkiego ruchu ({$distance} m)";
            }
        }

        // ⚡ Linia energetyczna
        if ($constraints->powerLine->exists) {
            $distance = $constraints->powerLine->distanceMeters;

            if ($distance !== null && $distance < 15) {
                $penalties['industry'] = ($penalties['industry'] ?? 0) + 20;
                $warnings[] = "Linia energetyczna w odległości {$distance} m";
            }
        }

        // ⚰️ Cmentarz
        if ($constraints->cemetery->exists) {
            $distance = $constraints->cemetery->distanceMeters;

            if ($distance !== null && $distance < 50) {
                $penalties['single_family'] = ($penalties['single_family'] ?? 0) + 10;
                $warnings[] = "Cmentarz w odległości {$distance} m";
            }
        }

        return [
            'penalties' => $penalties,
            'warnings' => $warnings,
        ];
    }
}
