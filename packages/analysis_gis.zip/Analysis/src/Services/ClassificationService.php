<?php

namespace Planogolny\Analysis\Services;

use Planogolny\Analysis\DTO\AnalysisInputDTO;
use Planogolny\Analysis\DTO\SurroundingsSnapshotDTO;
use Planogolny\GIS\DTO\BuildingDTO;
final class ClassificationService
{
    public function classifyBuilding(BuildingDTO $building): string
    {
        // TODO: implement full classification logic
        return 'unknown';
    }

    /**
     * @return array<string,int>
     */
    public function classify(AnalysisInputDTO $input): array
    {
        $scores = [
            'single_family' => 0,
            'multi_family'  => 0,
            'services'      => 0,
            'industry'      => 0,
            'green'         => 0,
        ];

        // 1️⃣ Promień 50 m – największa waga
        $this->applySnapshot(
            snapshot: $input->surroundings50m,
            weight: 0.5,
            scores: $scores
        );

        // 2️⃣ Promień 100 m – średnia waga
        $this->applySnapshot(
            snapshot: $input->surroundings100m,
            weight: 0.3,
            scores: $scores
        );

        // 3️⃣ Promień 200 m – najmniejsza waga
        $this->applySnapshot(
            snapshot: $input->surroundings200m,
            weight: 0.2,
            scores: $scores
        );

        return $this->normalize($scores);
    }

    private function applySnapshot(
        SurroundingsSnapshotDTO $snapshot,
        float $weight,
        array &$scores
    ): void {
        $total = max(1, $snapshot->total());

        $scores['single_family'] += (int) round(
            ($snapshot->residentialSingleCount / $total) * 100 * $weight
        );

        $scores['multi_family'] += (int) round(
            ($snapshot->residentialMultiCount / $total) * 100 * $weight
        );

        $scores['services'] += (int) round(
            ($snapshot->servicesCount / $total) * 100 * $weight
        );

        $scores['industry'] += (int) round(
            ($snapshot->industrialCount / $total) * 100 * $weight
        );

        $scores['green'] += (int) round(
            ($snapshot->greenCount / $total) * 100 * $weight
        );
    }

    private function normalize(array $scores): array
    {
        $sum = array_sum($scores);

        if ($sum === 0) {
            return $scores;
        }

        $normalized = [];

        foreach ($scores as $category => $score) {
            $normalized[$category] = (int) round(($score / $sum) * 100);
        }

        return $normalized;
    }
}
