<?php

declare(strict_types=1);

namespace Planogolny\Analysis\Samples;

use Planogolny\Analysis\DTO\AnalysisInputDTO;
use Planogolny\Analysis\DTO\SurroundingsSnapshotDTO;
use Planogolny\Analysis\DTO\ConstraintsDTO;
use Planogolny\Analysis\DTO\InfrastructureDTO;
use Planogolny\Analysis\DTO\DemographyDTO;

final class SampleAnalysisInputFactory
{
    /**
     * Typical suburban single-family housing area.
     *
     * Used as:
     * - reference input for domain validation
     * - scoring calibration baseline
     * - regression testing fixture
     */
    public static function suburbanPlot(): AnalysisInputDTO
    {
        return new AnalysisInputDTO(
            surroundings50m: new SurroundingsSnapshotDTO(
                residentialSingleCount: 6,
                residentialMultiCount: 0,
                serviceCount: 1,
                industrialCount: 0,
                greenCount: 3,
                totalObjects: 10
            ),
            surroundings100m: new SurroundingsSnapshotDTO(
                residentialSingleCount: 18,
                residentialMultiCount: 2,
                serviceCount: 3,
                industrialCount: 0,
                greenCount: 7,
                totalObjects: 30
            ),
            surroundings200m: new SurroundingsSnapshotDTO(
                residentialSingleCount: 45,
                residentialMultiCount: 6,
                serviceCount: 8,
                industrialCount: 1,
                greenCount: 20,
                totalObjects: 80
            ),
            constraints: new ConstraintsDTO(
                distanceToRiverMeters: null,
                distanceToRailMeters: 120,
                distanceToHighwayMeters: 600,
                distanceToPowerLineMeters: null,
                distanceToCemeteryMeters: 300
            ),
            infrastructure: new InfrastructureDTO(
                hasRoadAccess: true,
                hasElectricityNearby: true,
                hasWaterNearby: false
            ),
            demography: new DemographyDTO(
                populationChange5y: 4.2,
                populationChange10y: 8.9
            )
        );
    }

    /**
     * Dense urban area with mixed-use development.
     */
    public static function urbanPlot(): AnalysisInputDTO
    {
        return new AnalysisInputDTO(
            surroundings50m: new SurroundingsSnapshotDTO(
                residentialSingleCount: 1,
                residentialMultiCount: 8,
                serviceCount: 6,
                industrialCount: 0,
                greenCount: 0,
                totalObjects: 15
            ),
            surroundings100m: new SurroundingsSnapshotDTO(
                residentialSingleCount: 2,
                residentialMultiCount: 20,
                serviceCount: 15,
                industrialCount: 1,
                greenCount: 2,
                totalObjects: 40
            ),
            surroundings200m: new SurroundingsSnapshotDTO(
                residentialSingleCount: 4,
                residentialMultiCount: 50,
                serviceCount: 30,
                industrialCount: 4,
                greenCount: 6,
                totalObjects: 94
            ),
            constraints: new ConstraintsDTO(
                distanceToRiverMeters: null,
                distanceToRailMeters: 40,
                distanceToHighwayMeters: 200,
                distanceToPowerLineMeters: null,
                distanceToCemeteryMeters: null
            ),
            infrastructure: new InfrastructureDTO(
                hasRoadAccess: true,
                hasElectricityNearby: true,
                hasWaterNearby: true
            ),
            demography: new DemographyDTO(
                populationChange5y: 1.1,
                populationChange10y: 2.3
            )
        );
    }

    /**
     * Rural or semi-rural area with low development pressure.
     */
    public static function ruralPlot(): AnalysisInputDTO
    {
        return new AnalysisInputDTO(
            surroundings50m: new SurroundingsSnapshotDTO(
                residentialSingleCount: 1,
                residentialMultiCount: 0,
                serviceCount: 0,
                industrialCount: 0,
                greenCount: 9,
                totalObjects: 10
            ),
            surroundings100m: new SurroundingsSnapshotDTO(
                residentialSingleCount: 3,
                residentialMultiCount: 0,
                serviceCount: 1,
                industrialCount: 0,
                greenCount: 16,
                totalObjects: 20
            ),
            surroundings200m: new SurroundingsSnapshotDTO(
                residentialSingleCount: 6,
                residentialMultiCount: 0,
                serviceCount: 2,
                industrialCount: 0,
                greenCount: 42,
                totalObjects: 50
            ),
            constraints: new ConstraintsDTO(
                distanceToRiverMeters: 30,
                distanceToRailMeters: null,
                distanceToHighwayMeters: null,
                distanceToPowerLineMeters: 80,
                distanceToCemeteryMeters: null
            ),
            infrastructure: new InfrastructureDTO(
                hasRoadAccess: true,
                hasElectricityNearby: false,
                hasWaterNearby: false
            ),
            demography: new DemographyDTO(
                populationChange5y: -2.1,
                populationChange10y: -5.4
            )
        );
    }
}
